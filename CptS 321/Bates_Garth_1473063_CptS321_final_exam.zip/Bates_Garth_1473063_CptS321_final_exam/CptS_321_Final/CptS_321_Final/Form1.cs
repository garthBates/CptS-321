﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CptS_321_Final
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void loginToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private StringBuilder buildCheckingReport(Client temp)
        {
            StringBuilder report = new StringBuilder();
            double current = temp.client_checking.balance();

            report.AppendFormat("Balance: ${0}", current);
            

            return report;
        }

        private StringBuilder buildSavingsReport(Client temp)
        {
            StringBuilder report = new StringBuilder();
            double current = temp.client_savings.balance();
            double interest_rate = temp.client_savings.interest_rate;
            double total_interest = temp.client_savings.interest_gained;

            report.AppendFormat("Balance: ${0}", current);
            report.AppendLine();
            report.AppendFormat("Interest Rate: {0}%", interest_rate);
            report.AppendLine();
            report.AppendFormat("Total interest gained in the last 12 months: ${0}", total_interest);

            return report;
        }

        private StringBuilder buildLoanReport(Client temp)
        {
            StringBuilder report = new StringBuilder();
            double current = temp.client_loan.balance();
            double rate = temp.client_loan.interest_rate;

            report.AppendFormat("Remaining due: ${0}", current);
            report.AppendLine();
            report.AppendFormat("Interest Rate: {0}%", rate);

            return report;
        }

        private void logoutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // I would like to have a login window that takes a user name and pw and sends that to authentication before displaying balances
            Client temp = new Client("John", 1234567);

            temp.client_checking.add_funds(100.50);

            textBoxChecking.Text = buildCheckingReport(temp).ToString();
            textBoxSavings.Text = buildSavingsReport(temp).ToString();
            textBoxLoans.Text = buildLoanReport(temp).ToString();
        }

        private void logoutToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            textBoxSavings.Clear();
            textBoxChecking.Clear();
            textBoxLoans.Clear();
        }

        private void fromSavingsToCheckingToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        // This function is to take what the user enters in the toSavings box and tansfer that from checking
        private void toSavings_Click(object sender, EventArgs e)
        {
            // C# thinks toSavings.Text is a Datetime, i cannot figure out what is going on here
            double amount = Convert.ToDouble(toSavings.Text);
            
        }
        

        //this function takes the toChecking total and transfers it to savings
        private void toChecking_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
