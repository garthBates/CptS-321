﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CptS_321_Final
{
    class user
    {
        protected string name { get; set; }
        public int acc_number { get; set; }

        public user()
        {
        }
    }
}
