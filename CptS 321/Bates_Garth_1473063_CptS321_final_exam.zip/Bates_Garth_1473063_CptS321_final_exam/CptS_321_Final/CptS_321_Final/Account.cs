﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CptS_321_Final
{
    class Account : account_interface
    {
        public double current_balance { get; set; }
        public double min_balance { get; set; }

        public Account()
        {
            current_balance = 0.00;
            min_balance = 0.00;
        }

        /*
        protected int show_acc_num()
        {
            int number = user.acc_number;
        }
        */
        public double balance()
        {
            return this.current_balance;
        }

        public void transfer_funds(double subtractor)
        {
            if (check_balance(subtractor) == false)
            {
                return;
            }
            else
            {
                remove_funds(subtractor);
            }
        }

        private void remove_funds(double subtractor)
        {
            current_balance -= subtractor;
        }

        private bool check_balance(double subtractor)
        {
            bool sufficient = true;

            if (current_balance - min_balance < subtractor)
            {
                sufficient = false;
            }

            return sufficient;
        }

        public void add_funds(double incoming)
        {
            current_balance += incoming;
        }
    }
}
