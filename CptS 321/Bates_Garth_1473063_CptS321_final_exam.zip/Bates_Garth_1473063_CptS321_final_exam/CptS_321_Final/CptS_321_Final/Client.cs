﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CptS_321_Final
{
    class Client : user
    {
        protected int phone_number { get; set; }
        protected double loans { get; set; }

        public Savings client_savings;
        public Checking client_checking;
        public Loan client_loan;

        public Client(string client_name, int number)
        {
            this.name = client_name;
            this.phone_number = number;

            client_savings = new Savings();
            client_checking = new Checking();
            client_loan = new CptS_321_Final.Loan();
        }


    }
}
