﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CptS_321_Final
{
    class Employee : user
    {
        protected string job_title;

        public Employee(string employee_name, string position)
        {
            this.name = employee_name;
            this.job_title = position;
        }
    }
}
