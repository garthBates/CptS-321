﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CptS_321_Final
{
    class Savings : Account
    {
        public double interest_rate { get; set; }
        public double interest_gained { get; set; }

        public Savings()
        {
            min_balance = 5.0;
        }
    }
}
